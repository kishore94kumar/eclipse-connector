/*$(document).ready(function(){
    var cron_expr = $("#schedule-cron").val();
    if(cron_expr){
        $.ajax({
            url: "/bin/assetscheduler?schedulercron="+cron_expr, 
            success: function(result){
                alert(result);
            }
        });
    }
});*/