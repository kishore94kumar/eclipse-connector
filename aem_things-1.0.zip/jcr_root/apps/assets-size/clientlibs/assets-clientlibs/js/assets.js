if (!String.prototype.startsWith) {
    String.prototype.startsWith = function(searchString, position){
      position = position || 0;
      return this.substr(position, searchString.length) === searchString;
  };
}

$(document).ready(function(){

    /*-------------assets root page code starts -----------------*/

	var image = $(".assets-container").attr("data-json-image");
    var document = $(".assets-container").attr("data-json-document");
    var video = $(".assets-container").attr("data-json-video");
	if(image && document && video){
		var imageJson = JSON.parse(image);
        var documentJson = JSON.parse(document);
        var videoJson = JSON.parse(video);

        var finalHtml = "";
        var imagePath = "/content/eedigital-assets-size/assets/type.html?assettype=image";
        var videoPath = "/content/eedigital-assets-size/assets/type.html?assettype=video";
        var docPath = "/content/eedigital-assets-size/assets/type.html?assettype=document";
    
        finalHtml += "<table style=\"text-align: center;\"><tr><th>Asset Type</th><th>Asset Count</th><th>Asset Size</th></tr>"+
            "<tr><td><a href=\""+imagePath+"\">Images</a></td><td>"+imageJson.assetCount+"</td><td>"+imageJson.assetSize+"</td></tr>"+
                "<tr><td><a href=\""+docPath+"\">Documents</a></td><td>"+documentJson.assetCount+"</td><td>"+documentJson.assetSize+"</td></tr>"+
                    "<tr><td><a href=\""+videoPath+"\">Videos</a></td><td>"+videoJson.assetCount+"</td><td>"+videoJson.assetSize+"</td></tr>"
                    +"</table>";
        $("#assets-container").append(finalHtml);

    }
    else{
		var no_records_html = "";
		no_records_html += "<table><tr><th>Asset Type</th><th>Asset Count</th><th>Asset Size</th></tr><tr style=\"text-align: center;\"><td colspan=\"3\">No Records Found</td></tr></table>";
        $("#assets-container").append(no_records_html);
    }

    /*-------------assets root page code ends -----------------*/



    /*-------------assets type page code starts----------------*/


	var assetTypeParam = $("#assets-type-container").attr("data-request-parameter");
    var listPageUrl = "/content/eedigital-assets-size/assets/type/list.html?mimetype=";
    if(assetTypeParam){
        var json_to_parse = "";

	 	 if(assetTypeParam === "image"){
            json_to_parse = $("#assets-type-container").attr("data-json-image");
        }
        else if(assetTypeParam === "video"){
			json_to_parse = $("#assets-type-container").attr("data-json-video");
        }
        else if(assetTypeParam === "document"){
			json_to_parse = $("#assets-type-container").attr("data-json-document");
        }

        if((json_to_parse)&&(json_to_parse!="{}"))
        {
			var parsedJson = JSON.parse(json_to_parse);
            var finalHtml = "<table style=\"text-align: center;\"><tr><th>Asset Mimetype</th><th>Asset Count</th><th>Asset Size</th></tr>";
            for(var i=0;i<parsedJson.assetList.length;i++){
				finalHtml +=  "<tr><td><a href=\""+listPageUrl+""+encodeURIComponent(parsedJson.assetList[i][0].mimeType)+"\">"+parsedJson.assetList[i][0].mimeType+"</a></td>"+
                "<td>"+parsedJson.assetList[i][0].assetCount+"</td><td>"+parsedJson.assetList[i][0].assetSize +"</td></tr>";
            }
			finalHtml += "</table>";
            $("#assets-type-container").append(finalHtml);
        }
        else{
			var no_records_html = "";
			no_records_html += "<table><tr><th>Asset Type</th><th>Asset Count</th><th>Asset Size</th></tr><tr style=\"text-align: center;\"><td colspan=\"3\">No Records Found</td></tr></table>";
        	$("#assets-type-container").append(no_records_html);
    	}
    }
    else{
		var no_records_html = "";
		no_records_html += "<table><tr><th>Asset Type</th><th>Asset Count</th><th>Asset Size</th></tr><tr style=\"text-align: center;\"><td colspan=\"3\">No Records Found</td></tr></table>";
        $("#assets-type-container").append(no_records_html);
    }

    /*---------------assets type page code ends------------------------------*/




    /*----------------------assets list page code starts------------------------------ */

	var mimeType = $("#assets-list-container").attr("data-mimetype");
    var json_mimetype = "";
    if(mimeType){
        if(mimeType.toLowerCase().startsWith("image")){
			json_mimetype = $("#assets-list-container").attr("data-json-image");
         }
        else if(mimeType.toLowerCase().startsWith("video")){
			json_mimetype = $("#assets-list-container").attr("data-json-video");
        }
        else{
			json_mimetype = $("#assets-list-container").attr("data-json-document");
        }

         if(json_mimetype){
            var parsedJson = JSON.parse(json_mimetype);
			var finalHtml = "<table style=\"text-align: center;\"><tr><th>Asset</th><th>Asset Size</th></tr>";
			var noRecordFlag = 0;
            for(var i=0;i<parsedJson.assetList.length;i++){
                if(parsedJson.assetList[i][0].mimeType === mimeType){
                    var asset = parsedJson.assetList[i][0].assetIndividualPropertiesList;
                    noRecordFlag = 1;
                    for(var j=0;j<asset.length;j++){
                        finalHtml += "<tr><td><a href=\""+asset[j].assetPath+"\">"+asset[j].assetPath+"</a></td><td>"+asset[j].assetSize+"</td></tr>";
                    }
                }
            }

            if(noRecordFlag === 1){
            	$("#assets-list-container").append(finalHtml+"</table>");
            }
            else{
                var no_records_html = "";
				no_records_html += "<table><tr><th>Asset Path</th><th>Asset Size</th></tr><tr style=\"text-align: center;\"><td colspan=\"2\">No Records Found</td></tr></table>";
         		$("#assets-list-container").append(no_records_html);
            }

         }
    }
    else{
        var no_records_html = "";
        no_records_html += "<table><tr><th>Asset Path</th><th>Asset Size</th></tr><tr style=\"text-align: center;\"><td colspan=\"2\">No Records Found</td></tr></table>";
        $("#assets-list-container").append(no_records_html);
     }        

	/*----------------------assets list page code ends------------------------------ */

});
