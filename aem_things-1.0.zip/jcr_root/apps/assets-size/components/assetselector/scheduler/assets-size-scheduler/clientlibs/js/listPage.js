
$(document).ready(function() {

    $("#package-creator").css("display","block");
    $("#overlay").hide();
    $("#load-symbol").hide();
    $("#success-msg").hide();
    $("#error-msg").hide();
    $("#cron-container").show();
    var radioType ="cronTrigger";
    
    $("coral-radio[name='cron-radio']").click(function() {
        var radioVal = $(this).val();
        
        if(radioVal == "manualTrigger"){
            $("#cron-container").hide();
            radioType = radioVal;
            jobName = $("#jobName").val("");
            cron = $("#cron").val("");
        }
        else{
            $("#cron-container").show();
            radioType = radioVal;
        }
        
    }); 

   $(".corl-Form--PackageSubmit").click(function(){

       var cron,orderBy,action_url,jobName;

       action_url = $("#action-url").attr("data-action");
       jobName = $("#jobName").val();
       cron = $("#cron").val();
       orderBy = $("#orderBy").val();

		var fieldValidation = fieldValidate(radioType,jobName,cron);
       if(fieldValidation){

			$("#overlay").show();
       		$("#load-symbol").show();       
            $.post( 
               action_url, { 'jobName' : jobName, 'cron': cron, 'orderBy' : orderBy }, 
               function(data) {
                   if(data == "cronTrigger"){
                       $("#coral-alert-content").prepend("Cron Expression Scheduled Successfully.<br>");
                       $("#load-symbol").hide();
                       $("#success-msg").show();
                       $("#error-msg").hide();
                   }
                   else if(data == "ManualTrigger"){
                       $("#coral-alert-content").prepend("Manually Triggered Successfully.<br>");
                       $("#load-symbol").hide();
                       $("#success-msg").show();
                       $("#error-msg").hide();
                   }
                   else{
                       $("#load-symbol").hide();
                       $("#success-msg").hide();
                       $("#error-msg").show();
                   }
              });
       }
    });

    function fieldValidate(radioType,jobName,cron){
    	if(radioType == "cronTrigger"){
           if(!jobName){
				$("#jobName").focus();
                return false;
           }
           else if(!cron){
				$("#cron").focus();
                return false;
           }
       }
        return true;
    }

    $("#success-msg-close").click(function(){
        location.reload();
        
    });
    
    $("#error-msg-close").click(function(){
        location.reload();
        
    });

});